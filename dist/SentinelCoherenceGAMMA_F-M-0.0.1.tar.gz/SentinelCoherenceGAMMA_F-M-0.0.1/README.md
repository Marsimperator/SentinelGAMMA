# Example Package

This is a package for processing SAR-Sentinel coherence images with use of the Software: GAMMA.
It was created in a university project and is meant to allow users to process SAR-coherence with either srtm or palsar DEM. The Software package PyroSAR is required to interact with a installed GAMMA-environment.